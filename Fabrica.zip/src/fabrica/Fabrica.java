
package fabrica;


import jade.core.*;
import jade.core.behaviours.*;

import jade.lang.acl.ACLMessage;

/**
 *
 * @author utp
 */
public class Fabrica extends Agent{
    //
    class comportEnvia extends SimpleBehaviour{
        String nameAgent;
        
        public comportEnvia (String n) {nameAgent = n;}
        @Override
        public void action(){
            
            doWait(20000);
            ACLMessage acl = new ACLMessage(ACLMessage.REQUEST);
            AID agrec = new AID(nameAgent,AID.ISLOCALNAME);
            acl.addReceiver (agrec);
            acl.setContent("Mensaje1");
            send(acl);
        }
        
     

        @Override
        public boolean done() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    }
    
    protected void setup(){
        Object [] listaparametros = getArguments();
        String nameAgenteR = (String) listaparametros[0];
        
        System.out.println("Hola Mortales, soy el primer agente: "+ getLocalName());
        
        comportEnvia ce = new comportEnvia(nameAgenteR);
        addBehaviour(ce);
    }
}

