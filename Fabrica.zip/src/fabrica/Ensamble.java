import jade.core.Agent;
import jade.core.behaviours.*;
import java.lang.*;


public class Ensamble extends Agent {
    private static final String ONE_STATE = "Inicio";
    private static final String TWO_STATE = "Marco";
    private static final String THREE_STATE = "Relacion";
    private static final String FOUR_STATE = "Llanta";
    private static final String FIVE_STATE = "Direccion";
    private static final String SIX_STATE = "Fin";
    
    private final int CERO = 0;
    private final int UNO = 1;
    private final int DOS = 2;
    
private String entrada = "";
public void setup () {
    entrada = "012012212";
    MiFSMBehaviour b = new MiFSMBehaviour (this, entrada);
    addBehaviour (b);
}

private class MiFSMBehaviour extends FSMBehaviour{
    private int transicion = 0;
    private String entrada = "";
    public MiFSMBehaviour (Agent _agente,String ent){
        super(_agente);
        entrada = ent;
    }
    public void onStart() {
        registerFristState(new OneBehaviour(), ONE_STATE);      //Establece cúal es el estado inicial
        registerState(new TwoBehaviour(), TWO_STATE);           //Establece estados intermedios
        registerState(new TwoBehaviour(), THREE_STATE);         //.
        registerState(new TwoBehaviour(), FOUR_STATE);          //.
        registerState(new TwoBehaviour(), FIVE_STATE);          //.
        registerLastState(new TwoBehaviour(), SIX_STATE);       //Establece cúal es el estado final
        
        registerTransition (ONE_STATE, TWO_STATE, UNO);
        registerTransition (TWO_STATE, THREE_STATE, UNO);
        registerTransition (TWO_STATE, FOUR_STATE, CERO);
        registerTransition (TWO_STATE, FIVE_STATE, DOS);
        registerTransition (THREE_STATE, FOUR_STATE, CERO);
        registerTransition (THREE_STATE, FIVE_STATE, UNO);
        registerTransition (FOUR_STATE, THREE_STATE, UNO);
        registerTransition (FOUR_STATE, FIVE_STATE, CERO);
        registerTransition (FIVE_STATE, THREE_STATE, UNO);
        registerTransition (FIVE_STATE, FOUR_STATE, DOS);
        registerTransition (FIVE_STATE, SIX_STATE, CERO);
    }
}